# 喵伴 CyberVoc V2.0 固件 2.0.5.8

目标板：`CyberVoc-Board-V2_0`（ESP32-S3，16 MB Flash，360×360 圆屏）。

## 推荐刷机方式

使用 `merged-binary.bin`，写入地址为 `0x0`。这是包含 bootloader、分区表、应用、TITA+猫车载表情资源和“小特小特”唤醒模型的完整串口刷机镜像。

```powershell
python -m esptool --chip esp32s3 -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 16MB --flash_freq 80m 0x0 merged-binary.bin
```

也可以按照 `flash_args`/`flasher_args.json` 分区刷写。`custom_ota_binaries/CyberVoc-Board-V2_0.bin.xz.packed` 是压缩应用镜像，不包含完整资源分区。

## 本版内容

- 依据 Figma 图稿重做六扇区中文菜单，增加“返回桌面”。
- 新增设备设置：摸头触摸开关、音量、屏幕亮度。
- 修复打开系统信息时潜在的电量计空句柄崩溃/重启。
- 为车载瞬态表情增加最大驻留时间，避免长期卡住；继续保留断流优先提示。
- 车载表情全屏显示时隐藏电量、时钟和状态层，表情切换不再闪回待机眼睛。

## 注意

- 本包已通过主机回归、ESP-IDF 5.5.2 编译、资源/分区及合并镜像校验，但尚未代替用户完成实机烧录验收。
- 应用原始镜像大于 3000 KiB 的 `ota_1`，不得把 `CyberVoc-Board-V2_0.bin` 直接写入该分区；压缩 OTA 包在 3000 KiB 容量内。
- 首次刷入建议使用完整合并镜像，并备份设备中需要保留的配置。

