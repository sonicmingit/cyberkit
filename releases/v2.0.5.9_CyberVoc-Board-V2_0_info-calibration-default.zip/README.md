# 喵伴 CyberVoc V2.0 固件 2.0.5.9

目标板：`CyberVoc-Board-V2_0`（ESP32-S3，16 MB Flash，360×360 圆屏）。

## 推荐刷机方式

使用 `merged-binary.bin`，写入地址为 `0x0`。这是包含 bootloader、分区表、应用、TITA + 004 默认车载表情资源和“小特小特”唤醒模型的完整串口刷机镜像。

```powershell
python -m esptool --chip esp32s3 -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 16MB --flash_freq 80m 0x0 merged-binary.bin
```

也可以按照 `flash_args` / `flasher_args.json` 分区刷写。`custom_ota_binaries/CyberVoc-Board-V2_0.bin.xz.packed` 是压缩应用镜像，不包含完整资源分区。

## 本版内容

- 系统信息页改为固定缓冲区、进入页面时按需刷新，不再由 250 ms 定时器反复复制长文本。
- 重新校准显示 0～100% 稳定样本进度，并容忍孤立震动样本；“安装方向”改名为“车头方向”并补充说明。
- 车载设置增加持久化“调试显示”开关；启用后全屏表情顶部显示当前中文状态。
- 第二套车载资源由猫表情替换为 `004-默认表情-v1` 的九个实时事件状态。

## 注意

- 本包已通过 35 项主机回归、ESP-IDF 5.5.2 编译、资源/分区、压缩 OTA 解压及合并镜像校验，但尚未代替用户完成实机烧录验收。
- 应用原始镜像大于 3000 KiB 的 `ota_1`，不得把 `CyberVoc-Board-V2_0.bin` 直接写入该分区；压缩 OTA 包在 3000 KiB 容量内。
- 首次刷入建议使用完整合并镜像，并备份设备中需要保留的配置。
