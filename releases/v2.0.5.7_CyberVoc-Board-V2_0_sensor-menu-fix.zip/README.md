# 喵伴 V2.0 传感器与菜单修复开发固件 2.0.5.7

目标：CyberVoc-Board-V2_0 / ESP32-S3 / 16MB Flash。已完成 ESP-IDF 5.5.2 编译、34 项主机回归、资源/模型容量验证；未烧录或实机验收。

菜单 HEAD 为头部触摸开关（GPIO8），不关闭屏幕触摸；INFO 为设备信息。CAR 长按或 SET 进入设置，PACK 切换 TITA/CAT，AXIS 选择前向轴，CALIBRATE 后静止约 2 秒。车载开启时头部触摸和 DOA 动作临时暂停。

资源仅 TITA 与猫，经过抽帧。TITA 缺少加减速/急刹专用素材，三项使用中性巡航回退。唤醒词仅“小特小特”。

## 更新说明

本次必须同时更新应用、assets、model。仅更新压缩应用不会更换旧表情和旧唤醒模型。

需要保留 NVS/Wi-Fi 设置时，使用包内 flash_args 的分区写入布局；在确认板型和串口之后，可在解压目录使用 ESP-IDF 配套工具：

    python -m esptool --chip esp32s3 -p PORT write_flash @flash_args

PowerShell 中将 @flash_args 写为字符串 "@flash_args"。PORT 替换成已确认设备串口；本轮没有执行此操作。

merged-binary.bin 从 0x0 写入，适合完整安装；它包含分区间填充区域，整段烧录会覆盖 NVS 所在区间，可能清除既有配置。不要把 merged-binary.bin 当作 OTA 应用上传。

custom_ota_binaries 中的 .packed 是压缩应用，大小适配 ota_1，已验证解压后与当前应用完全一致；仅供确认 bootloader/升级链路兼容后的后续应用 OTA，本轮未验证设备 OTA/回退。

manifest.json 提供容量和 SHA256；主机回归、当前限制及实机验收步骤见仓库 文档/07-迭代记录/03-审查修复与菜单扩展.md。
