# 03-审查修复与菜单扩展

状态：待实机验证。关联：需求-001～004，新增菜单头部触摸开关与设备信息入口。

## 本轮范围

- 修复审查 R01～R07，补充 IMU 单帧冲击、数据有效性、轴向设置和触摸事件隔离。
- 新菜单增加头部触摸开关和设备基础信息；业务状态与页面分离，写 Flash 在应用任务执行。
- 实测构建资源容量；三套放不下时仅保留 TITA、猫表情。
- 核查实际唤醒模型，不能同时容纳双词条时优先“小特小特”；模型缺失与容量不足分别记录。
- 主机回归、ESP-IDF 5.5.2 V2.0 正式构建和最终产物尺寸检查。

## 非目标与边界

不改硬件接线、不自动烧录或推送。台架触摸、IMU 安装方向、实车噪声和唤醒准确率仍需设备验证。

## 用户本轮变更

2026-09-07：用户授权修复审查问题，并明确资源不足时优先 TITA+猫、唤醒词不足时优先“小特小特”；新增菜单触摸开关、信息菜单。

## 验收

主机回归通过，构造期间不获取 Board 单例，手势不触发额外点击，取消提醒失效，IMU 失败可诊断/恢复；完成构建并如实记录资源、模型能力及待实机项。

## 基线和文件级实现

分支 `feature/car-mode`，HEAD `8a93a37`，本轮仍未提交。保留此前未提交的车载/菜单/MCP 实现。本轮版本 `2.0.5.7` 用于区别含已知缺陷的 `2.0.5.6`，没有为了绕过发布脚本而跳过构建。

| 审查项 | 实际修复 |
|---|---|
| R01 构造重入 | `feature_ui` 构造只创建对象，`ui_ready` 前不读取 Board；板构造末尾排队启动 `feature_services_start` |
| R02 PSRAM 栈写 Flash | UI 按钮只 Schedule 命令；设置在应用任务写入；保留旧 bool 的 NVS u8 类型，写入成功才改变启用状态 |
| R03 滑动误点击 | 按下记录扇区；移动超过 14 px 即取消点击资格；按下/释放同项目才执行；长按、PRESS_LOST、页面切换抑制后的 CLICKED 不执行 |
| R04 IMU 字节序 | CTRL1=0x40（小端、自增），CTRL2=0x27、CTRL3=0x47、CTRL7=0x03，逐项回读；读取 STATUS0 与 24 位采样计数器，拒绝重复帧 |
| R05 坡道误判 | 使用实时间隔及陀螺积分更新重力方向，仅在小残差时慢速修正；不把持续加速度吸收到重力；增加轴向错误提示 |
| R06 无恢复 | 同一 IMU 任务持续存在，3 秒重试两个地址；1 秒无新样本显示 SIGNAL LOST，1.5 秒无新样本移除设备后重连，重连重新校准 |
| R07 过期提醒 | `timer_state.h` 单调截止时间和 generation；100 ms 合并心跳在应用任务轮询，取消/重新开始使已排队提醒失效；移除旧一次性 timer 回调 |

额外修复：IMU 超量程/NaN 无效化、单帧颠簸锁存 400 ms、轴向持久化为单个 orientation 键、未变化表情不重复启动；车载显示走无镜像的全脸 dialog 布局，语音/通知优先，车载期间临时抑制 DOA 动作、摇晃唤醒和头部触摸反馈，不改用户持久开关。

`Cst816sTouch` 保留 adapter IRQ 唤醒，通过板级回调跟踪实际读取；按下后没有新 IRQ 仍读取直到释放，已释放后不轮询休眠芯片。总线错误/越界坐标按取消处理，不制造成功点击。失败初始化释放 IO，未修改 managed_components 驱动。

AFE 选择真实模型并核对词条索引，增加空结果/初始化失败处理。共享显示接口不依赖 V2 板级头；其他板型仍使用自己的配置。本轮仅构建 V2.0，其他板型和实机 OTA 不视为已验证。

## 菜单和使用方式

六项顺时针：CAR、TIMER、HEAD、INFO、SET、禁用预留 `+`。

- CAR 单击启停，长按进入设置；服务离开页面仍维护状态。
- TIMER 设置 1～1440 分钟，默认 5 分钟，按钮 ±5 分钟、开始、暂停、继续、取消。按单调时间计时，重启不恢复。
- HEAD 切换 GPIO8 头部触摸并保存，默认关闭；屏幕触摸始终保留。车载启用时头部触摸暂不触发语音/表情，退出车载恢复用户设置。
- INFO 查看固件版本、IDF、网络类型、电量/充电、Flash/PSRAM、空闲堆、运行秒数、IMU、头部触摸和当前唤醒词。可纵向滚动，REFRESH 更新快照，MENU 返回。
- SET 中 PACK 切换 TITA/CAT；AXIS 循环 X+/X-/Y+/Y-/Z+/Z-；CALIBRATE 清除校准并要求静止约 2 秒。轴向应按安装方向确认，竖直前向轴提示 CHECK AXIS。

沿用现有英文字体标签，未增加整套中文字库。360×360 的实际裁切、命中和显示效果待设备检查。

## 资源与唤醒模型

原 assets 加上未抽帧 TITA、猫已超过 5500 KiB；按用户优先级不打包第三套双眼。`car_packs/tita/manifest.json` 和 `car_packs/cat/manifest.json` 记录原素材来源和哈希，原始 EAF 不改。

`scripts/prepare_v2_assets.py` 在 build/v2_assets 生成资源：TITA 每动画最多 6 帧、猫保留现有每动画 4 帧、原 insert 保留 12 帧（包含末尾控制帧），相应调整 fps 近似保持时长。校验 EAF 长度/校验和、360×360 尺寸、RLE 每块解码像素数，控制帧原样保留。TITA 缺少专用加速/减速/急刹素材，这三项明确回退为中性巡航；猫有独立对应素材，不伪造 TITA 专用动画。

V2.0 显式关闭原喵伴与 ESP32-S3 默认“你好小智”，只选择 `wn9_xiaotexiaote_tts2`。原模型文件约 291 KB，两个同量级模型超过 300 KiB；现有依赖也缺少“你好,小特”模型。因此采用用户允许的“小特小特”单词条回退，双词识别未实现。

`scripts/verify_v2_images.py` 已接入 V2 build 和 flash 依赖：读取实际二进制分区表，校验应用/assets/model 体积和写入地址，要求恰好一个正确模型，验证 18 个车载状态资源引用、资源镜像校验和及 RLE 帧。错误直接阻止构建成功，避免 SDK 只提示推荐 model 大小而漏掉超限。

## 主机验证

工具：本机 Zig 0.16.0 C++17；测试为合成输入和 SDK/LVGL/总线替身，不是实测数据。

```powershell
D:/Temp/codex-miaoban-review-tools/ziglang/zig.exe c++ -std=c++17 tests/review/car_motion_review.cc -o D:/Temp/car_motion_regression.exe
D:/Temp/car_motion_regression.exe
python tests/review/run_feature_probes.py --compiler D:/Temp/codex-miaoban-review-tools/ziglang/zig.exe
python tests/review/run_touch_probes.py --compiler D:/Temp/codex-miaoban-review-tools/ziglang/zig.exe
```

实际结果：IMU 12/12；菜单与计时器 16/16；CST816S 6/6，总计 34 项通过。回调探针从当前源码抽取实际函数，计时器使用实际服务及状态头，不复制旧业务算法。

## 构建环境和复现

Windows 中文源码路径触发工具链路径编码错误，使用英文快照 `D:/Temp/cyberkit_fix_20260907`，ESP-IDF 5.5.2 + 自带 Python 3.13，目标 ESP32-S3，使用有效 sdkconfig。

快照需排除 .git/build/releases/__pycache__，并把快照 dependencies.lock 中 audio_doa 的本地绝对路径改为快照下 components 同名目录（只改快照路径，不升级依赖或删除锁）。设置 `PYTHONUTF8=1`，避免第三方资源打包脚本的勾号在 GBK 输出失败。若重打包模型遇 Windows 只读目录错误，只清理已核实 build/srmodels 范围内的只读属性，再重新构建。

```powershell
. D:/Espressif/frameworks/esp-idf-v5.5.2/export.ps1
$env:PYTHONUTF8='1'
idf.py reconfigure build
idf.py gen_compressed_ota
idf.py merge-bin
python scripts/verify_v2_images.py --build-dir build
```

`merge-bin` 会把尾随参数当 esptool 参数，不能把 `gen_compressed_ota` 接在同一条 merge-bin 命令后。三个命令分别执行并检查退出码。

## 实机待验收（尚未烧录）

1. 完整更新应用/assets/model 后开机，确认 Feature UI 初始化、features 服务、QMI 配置回读、Active wake word 日志，没有构造卡死或 PSRAM Flash 断言。
2. HEAD 开启/关闭各测试短触摸、长触摸、松开重触摸、快速连触和重启记忆；屏幕点击、长按、拖出再拖回、长按后松手、上下滑菜单不误切开关；车载打开时确认头部触摸按策略暂停。
3. 静止约 2 秒后确认 IMU 校准；核对静态加速度模长约 1g、各轴方向、正负转向和重连日志。断开/恢复 IMU 后无需重启即可重新校准，屏幕触摸不被共享总线拖死。
4. TITA/CAT 切换、转向/颠簸/急刹回放，检查全脸方向、颜色、帧率、提示抢占、语音结束恢复；信息页面滚动和刷新正常。
5. 说“小特小特”，确认识别日志和上报词；安静、扬声器播放、车载噪声条件分别记录漏检/误触发。旧“你好喵伴”不再作为默认模型。
6. 计时器结束/取消边界、连续切页、长时间运行、内存/栈余量、原有联网/底座/电量功能回归。压缩 OTA 容量通过不等于已验证设备升级/回退。

## 交付状态

未提交、未推送、未烧录。实现与构建已完成，硬件、长期稳定性及 OTA 实机流程仍待验证。

### 最终构建证据

ESP-IDF 5.5.2 `build`、`gen_compressed_ota`、`merge-bin` 均退出 0；`git diff --check` 通过。比较当前工作区与实际编译快照的 260 个 main 源码/头文件/JSON，以及根/main CMake 和两份资源脚本，无不一致。

| 产物 | 实际字节 | 对应容量 | 结论 |
|---|---:|---:|---|
| 应用 | 4,503,040 | ota_0 6,144,000 | 通过 |
| expression_assets.bin | 5,351,115 | 5,632,000 | 通过，余 280,885 |
| srmodels.bin | 291,070 | 307,200 | 通过，余 16,130 |
| 压缩 OTA .packed | 2,384,952 | ota_1 3,072,000 | 容量通过 |
| merged-binary.bin | 15,286,526 | Flash 16,777,216 | 布局通过 |

实际资源镜像含 42 个文件、18 个车载状态映射，83 个抽帧/控制帧结构验证通过。压缩包从偏移 328 的 XZ 数据解压，与当前应用逐字节一致；合并镜像中的全部六个分区载荷均与 flasher_args.json 对应文件逐字节一致。应用原始体积超过 ota_1 的编译提示仍存在，但本配置的 ota_1 用于压缩暂存，已核对压缩容量；没有把这一提示当成普通双槽 OTA 已通过。

应用 SHA256：`990fb09004bc931ad574da78c6a741e62fc60b9d4f51d9b056ae173662a70196`。
合并镜像 SHA256：`a8636e8a4ab44ae353cdf9800d5ada51c26dc512de708892be670e64c2e86971`。

交付包：`releases/v2.0.5.7_CyberVoc-Board-V2_0_sensor-menu-fix.zip`。包含完整合并镜像、各分区镜像、压缩应用、flash_args、README 和哈希清单；旧 v2.0.5.6 产物保持原样。独立清单 `releases/v2.0.5.7_sensor-menu-fix_manifest.json`。

本次需一起更新应用、assets 和 model；只应用 OTA 不足以获得新表情和新唤醒词。保留现有 NVS 时优先按分区文件写入；完整 merged 从 0x0 整段写入会覆盖包括 NVS 间隙在内的区域，包内 README 已说明。此处只是交付说明，本轮没有执行写入。

构建保留上游已有未使用变量、字符串常量和 bootloader 链接脚本警告；无编译错误。GUI 裁切、真实触摸/安装轴向、噪声唤醒与升级稳定性按上节继续实机验收。
